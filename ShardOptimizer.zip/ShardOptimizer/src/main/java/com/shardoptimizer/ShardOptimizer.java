package com.shardoptimizer;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.shardoptimizer.ShardData.Shard;
import com.shardoptimizer.ShardData.ShardClickArea;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Mod(modid = "shardoptimizer", name = "Combat Shard Optimizer", version = "1.0")
public class ShardOptimizer {
    
    private boolean displayEnabled = false;
    private boolean showNextUpgrade = false;
    private boolean hasScannedThisOpen = false;
    
    private static final String KEY_CATEGORY = "Combat Shard Optimizer";
    private KeyBinding toggleDisplayKey;
    private KeyBinding toggleModeKey;
    
    private static final String BAZAAR_API = "https://api.hypixel.net/v2/skyblock/bazaar";
    
    private Map<String, Double> bazaarPrices = new ConcurrentHashMap<>();
    private long lastUpdate = 0;
    private static final long UPDATE_INTERVAL = 60000;
    private boolean isUpdating = false;
    private String updateStatus = "Ready";
    private int tickCounter = 0;
    
    private List<Shard> shards;
    private List<ShardClickArea> clickableShards = new ArrayList<>();
    
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
        
        toggleDisplayKey = new KeyBinding("Toggle Shard Display", Keyboard.KEY_K, KEY_CATEGORY);
        toggleModeKey = new KeyBinding("Toggle Display Mode", Keyboard.KEY_L, KEY_CATEGORY);
        ClientRegistry.registerKeyBinding(toggleDisplayKey);
        ClientRegistry.registerKeyBinding(toggleModeKey);
        
        shards = ShardData.createShardList();
        new Thread(this::updateBazaarPrices).start();
    }
    
    @SubscribeEvent
    public void onGuiDraw(GuiScreenEvent.BackgroundDrawnEvent event) {
        if (event.gui instanceof GuiChest) {
            GuiChest chest = (GuiChest) event.gui;
            ContainerChest container = (ContainerChest) chest.inventorySlots;
            IInventory inv = container.getLowerChestInventory();
            String chestName = inv.getDisplayName().getUnformattedText();
            
            if (chestName.contains("Attribute Menu")) {
                if (!hasScannedThisOpen) {
                    scanChestForShards(inv);
                    hasScannedThisOpen = true;
                }
            }
        } else {
            hasScannedThisOpen = false;
        }
    }
    
    private void scanChestForShards(IInventory inv) {
        String chestName = inv.getDisplayName().getUnformattedText();
        
        if (chestName.contains("Attribute Menu")) {
            synchronized (shards) {
                for (Shard shard : shards) {
                    shard.owned = false;
                    shard.currentTier = 0;
                }
            }
        }
        
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack stack = inv.getStackInSlot(i);
            if (stack != null) {
                String displayName = stack.getDisplayName();
                String cleanName = displayName.replaceAll("\\u00A7.", "").trim();
                int stackSize = stack.stackSize;
                
                synchronized (shards) {
                    for (Shard shard : shards) {
                        if (cleanName.contains(shard.displayName) || 
                            (cleanName.contains("Shard") && cleanName.contains(shard.displayName))) {
                            shard.owned = true;
                            int[] reqs = shard.getTierRequirements();
                            for (int tier = reqs.length - 1; tier >= 0; tier--) {
                                if (stackSize >= reqs[tier]) {
                                    shard.currentTier = tier + 1;
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
    }
    
    private void updateBazaarPrices() {
        if (isUpdating) return;
        isUpdating = true;
        updateStatus = "Updating...";
        
        try {
            URL url = new URL(BAZAAR_API);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
            
            JsonParser parser = new JsonParser();
            JsonObject json = parser.parse(response.toString()).getAsJsonObject();
            
            if (json.get("success").getAsBoolean()) {
                JsonObject products = json.getAsJsonObject("products");
                Map<String, Double> newPrices = new HashMap<>();
                
                for (Map.Entry<String, com.google.gson.JsonElement> entry : products.entrySet()) {
                    String key = entry.getKey();
                    JsonObject product = entry.getValue().getAsJsonObject();
                    JsonObject quickStatus = product.getAsJsonObject("quick_status");
                    double buyPrice = quickStatus.get("buyPrice").getAsDouble();
                    newPrices.put(key, buyPrice);
                }
                
                bazaarPrices.clear();
                bazaarPrices.putAll(newPrices);
                
                lastUpdate = System.currentTimeMillis();
                updateStatus = "Updated";
            } else {
                updateStatus = "API Error";
            }
        } catch (Exception e) {
            updateStatus = "Failed: " + e.getMessage();
            e.printStackTrace();
        } finally {
            isUpdating = false;
        }
    }
    
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        
        tickCounter++;
        if (tickCounter % 1200 == 0) {
            long timeSinceUpdate = System.currentTimeMillis() - lastUpdate;
            if (timeSinceUpdate > UPDATE_INTERVAL) {
                new Thread(this::updateBazaarPrices).start();
            }
        }
    }
    
    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (toggleDisplayKey.isPressed()) {
            displayEnabled = !displayEnabled;
        }
        if (toggleModeKey.isPressed()) {
            showNextUpgrade = !showNextUpgrade;
        }
    }
    
    @SubscribeEvent
    public void onMouseInput(InputEvent.MouseInputEvent event) {
        if (!displayEnabled) return;
        
        Minecraft mc = Minecraft.getMinecraft();
        
        if (Mouse.getEventButtonState() && Mouse.getEventButton() == 0) {
            int mouseX = Mouse.getEventX() * mc.currentScreen.width / mc.displayWidth;
            int mouseY = mc.currentScreen.height - Mouse.getEventY() * mc.currentScreen.height / mc.displayHeight - 1;
            
            for (ShardClickArea area : clickableShards) {
                if (area.isHovered(mouseX, mouseY)) {
                    String command = "/bz " + area.bazaarId;
                    mc.thePlayer.sendChatMessage(command);
                    GuiScreen.setClipboardString(String.valueOf(area.quantity));
                    break;
                }
            }
        }
    }
    
    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
        if (!displayEnabled) return;
        
        Minecraft mc = Minecraft.getMinecraft();
        clickableShards.clear();
        
        int x = 10;
        int y = 10;
        
        int maxedCount = 0;
        for (Shard shard : shards) {
            if (shard.isMaxed()) maxedCount++;
        }
        
        String modeText = showNextUpgrade ? "(Next Upgrade)" : "(Max Tier)";
        mc.fontRendererObj.drawStringWithShadow("Combat Shard Optimizer " + modeText + " [" + maxedCount + "/" + shards.size() + " Maxed]", x, y, 0xFFD700);
        y += 12;
        mc.fontRendererObj.drawStringWithShadow(toggleDisplayKey.getKeyDescription() + "=Toggle | " + 
            toggleModeKey.getKeyDescription() + "=Mode | " + updateStatus, x, y, 0xAAAAAA);
        y += 15;
        
        List<Shard> sortedShards = new ArrayList<>(shards);
        
        double bestEfficiency = 0;
        for (Shard shard : sortedShards) {
            if (!shard.isMaxed()) {
                double efficiency = shard.getEfficiencyRaw(bazaarPrices, showNextUpgrade);
                if (efficiency > bestEfficiency) {
                    bestEfficiency = efficiency;
                }
            }
        }
        
        final double finalBestEfficiency = bestEfficiency;
        sortedShards.sort((a, b) -> {
            if (a.isMaxed() && !b.isMaxed()) return 1;
            if (!a.isMaxed() && b.isMaxed()) return -1;
            double effA = a.getEfficiencyPercent(bazaarPrices, showNextUpgrade, finalBestEfficiency);
            double effB = b.getEfficiencyPercent(bazaarPrices, showNextUpgrade, finalBestEfficiency);
            return Double.compare(effB, effA);
        });
        
        Shard bestShard = null;
        for (Shard shard : sortedShards) {
            if (!shard.isMaxed()) {
                bestShard = shard;
                break;
            }
        }
        
        if (bestShard != null) {
            double totalCost = bestShard.getTotalCost(bazaarPrices, showNextUpgrade);
            String rarityColor = getRarityColor(bestShard.rarity);
            int quantity = showNextUpgrade ? bestShard.getQuantityForNextTier() : bestShard.getQuantityToMax();
            int combatValue = showNextUpgrade ? bestShard.getCombatValueForNextTier() : bestShard.getCombatValueToMax();
            String tierInfo = showNextUpgrade ? 
                " (Tier " + bestShard.currentTier + " -> " + (bestShard.currentTier + 1) + ")" :
                " (Tier " + bestShard.currentTier + " -> " + bestShard.getMaxTier() + ")";
            
            mc.fontRendererObj.drawStringWithShadow("Best Shard" + tierInfo + ":", x, y, 0x55FF55);
            y += 12;
            int nameY = y;
            mc.fontRendererObj.drawStringWithShadow(rarityColor + bestShard.name, x + 5, y, 0xFFFFFF);
            int textWidth = mc.fontRendererObj.getStringWidth(bestShard.name);
            clickableShards.add(new ShardClickArea(x + 5, nameY, textWidth, 10, bestShard.bazaarId, quantity));
            y += 12;
            mc.fontRendererObj.drawStringWithShadow("Cost: " + formatCoins(totalCost) + " (" + quantity + "x)", x + 5, y, 0xFFD700);
            y += 12;
            mc.fontRendererObj.drawStringWithShadow("Combat Value: +" + combatValue, x + 5, y, 0xFF5555);
            y += 12;
            mc.fontRendererObj.drawStringWithShadow("Efficiency: " + 
                String.format("%.1f%%", bestShard.getEfficiencyPercent(bazaarPrices, showNextUpgrade, finalBestEfficiency)), x + 5, y, 0x55FF55);
            y += 15;
        }
        
        mc.fontRendererObj.drawStringWithShadow("Top 7 Upgrades:", x, y, 0x55FFFF);
        y += 12;
        
        int count = 0;
        for (Shard shard : sortedShards) {
            if (!shard.isMaxed() && count < 7) {
                double totalCost = shard.getTotalCost(bazaarPrices, showNextUpgrade);
                double effPercent = shard.getEfficiencyPercent(bazaarPrices, showNextUpgrade, finalBestEfficiency);
                String rarityColor = getRarityColor(shard.rarity);
                int quantity = showNextUpgrade ? shard.getQuantityForNextTier() : shard.getQuantityToMax();
                
                String text = rarityColor + (count + 1) + ". " + shard.name + 
                    " (" + formatCoins(totalCost) + " | " + String.format("%.1f%%", effPercent) + ")";
                
                int textWidth = mc.fontRendererObj.getStringWidth(text);
                clickableShards.add(new ShardClickArea(x + 5, y, textWidth, 12, shard.bazaarId, quantity));
                
                mc.fontRendererObj.drawStringWithShadow(text, x + 5, y, 0xFFFFFF);
                y += 12;
                count++;
            }
        }
    }
    
    private String getRarityColor(String rarity) {
        switch (rarity) {
            case "Common": return "\u00A7f";
            case "Uncommon": return "\u00A7a";
            case "Rare": return "\u00A79";
            case "Epic": return "\u00A75";
            case "Legendary": return "\u00A76";
            default: return "\u00A7f";
        }
    }
    
    private String formatCoins(double coins) {
        if (coins >= 1000000000) {
            return String.format("%.1fB", coins / 1000000000.0);
        } else if (coins >= 1000000) {
            return String.format("%.1fM", coins / 1000000.0);
        } else if (coins >= 1000) {
            return String.format("%.1fK", coins / 1000.0);
        }
        return String.format("%.0f", coins);
    }
}