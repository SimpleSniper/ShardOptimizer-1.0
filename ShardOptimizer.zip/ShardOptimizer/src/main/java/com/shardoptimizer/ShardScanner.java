package com.shardoptimizer;

import com.shardoptimizer.ShardData.Shard;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;

import java.util.List;

public class ShardScanner {
    
    private boolean hasScannedThisOpen = false;
    
    public boolean hasScannedThisOpen() {
        return hasScannedThisOpen;
    }
    
    public void setScanned(boolean scanned) {
        this.hasScannedThisOpen = scanned;
    }
    
    public void resetScan() {
        this.hasScannedThisOpen = false;
    }
    
    public void scanChestForShards(IInventory inv, List<Shard> shards) {
        String chestName = inv.getDisplayName().getUnformattedText();
        
        // Only reset if we're in the Attribute Menu
        if (chestName.contains("Attribute Menu")) {
            synchronized (shards) {
                for (Shard shard : shards) {
                    shard.owned = false;
                    shard.currentTier = 0;
                }
            }
        }
        
        // Then scan the chest and update what we find
        for (int i = 0; i < inv.getSizeInventory(); i++) {
            ItemStack stack = inv.getStackInSlot(i);
            if (stack != null) {
                String displayName = stack.getDisplayName();
                
                // Check if it's a shard item (either has "Shard" in name or matches our shard list)
                String cleanName = displayName.replaceAll("\\u00A7.", "").trim();
                int stackSize = stack.stackSize;
                
                synchronized (shards) {
                    for (Shard shard : shards) {
                        // Match by display name or if the item name contains the shard's display name
                        if (cleanName.contains(shard.displayName) || 
                            (cleanName.contains("Shard") && cleanName.contains(shard.displayName))) {
                            shard.owned = true;
                            int[] reqs = shard.getTierRequirements();
                            for (int tier = reqs.length - 1; tier >= 0; tier--) {
                                if (stackSize >= reqs[tier]) {
                                    shard.currentTier = tier + 1;
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
    }
}
