package com.shardoptimizer;

import java.util.*;

public class ShardData {
    
    public static final Map<String, int[]> TIER_REQUIREMENTS = new HashMap<String, int[]>() {{
        put("Common", new int[]{1, 4, 9, 15, 22, 30, 40, 54, 72, 96});
        put("Uncommon", new int[]{1, 3, 6, 10, 15, 21, 28, 36, 48, 64});
        put("Rare", new int[]{1, 3, 6, 9, 13, 17, 22, 28, 36, 48});
        put("Epic", new int[]{1, 2, 4, 6, 9, 12, 16, 20, 25, 32});
        put("Legendary", new int[]{1, 2, 3, 5, 7, 9, 12, 15, 19, 24});
    }};
    
    public static class Shard {
        public String name;
        public String bazaarId;
        public double fallbackPrice;
        public int combatValue;
        public String rarity;
        public boolean owned;
        public int currentTier;
        public String displayName;
        
        public Shard(String name, String bazaarId, double fallbackPrice, int combatValue, String rarity, String displayName) {
            this.name = name;
            this.bazaarId = bazaarId;
            this.fallbackPrice = fallbackPrice;
            this.combatValue = combatValue;
            this.rarity = rarity;
            this.owned = false;
            this.currentTier = 0;
            this.displayName = displayName;
        }
        
        public int[] getTierRequirements() {
            return TIER_REQUIREMENTS.getOrDefault(rarity, new int[]{1});
        }
        
        public int getMaxTier() {
            return getTierRequirements().length;
        }
        
        public int getQuantityForNextTier() {
            int[] reqs = getTierRequirements();
            if (currentTier >= reqs.length) return 0;
            
            int totalNeeded = reqs[currentTier];
            int alreadyHave = currentTier > 0 ? reqs[currentTier - 1] : 0;
            return totalNeeded - alreadyHave;
        }
        
        public int getQuantityToMax() {
            int[] reqs = getTierRequirements();
            int maxTotal = reqs[reqs.length - 1];
            int alreadyHave = currentTier > 0 ? reqs[currentTier - 1] : 0;
            return maxTotal - alreadyHave;
        }
        
        public int getCombatValueForNextTier() {
            return combatValue / 100;
        }
        
        public int getCombatValueToMax() {
            int[] reqs = getTierRequirements();
            int tiersRemaining = reqs.length - currentTier;
            return tiersRemaining * (combatValue / 100);
        }
        
        public double getTotalCost(Map<String, Double> prices, boolean nextUpgrade) {
            double pricePerShard = prices.getOrDefault(bazaarId, fallbackPrice * 1000000.0);
            int quantity = nextUpgrade ? getQuantityForNextTier() : getQuantityToMax();
            return pricePerShard * quantity;
        }
        
        public double getEfficiencyRaw(Map<String, Double> prices, boolean nextUpgrade) {
            double totalCost = getTotalCost(prices, nextUpgrade);
            if (totalCost == 0) return 0;
            int combatValue = nextUpgrade ? getCombatValueForNextTier() : getCombatValueToMax();
            return combatValue / totalCost;
        }
        
        public double getEfficiencyPercent(Map<String, Double> prices, boolean nextUpgrade, double bestEfficiency) {
            double efficiency = getEfficiencyRaw(prices, nextUpgrade);
            if (bestEfficiency > 0) {
                return Math.min((efficiency / bestEfficiency) * 100.0, 100.0);
            }
            return 100.0;
        }
        
        public boolean isMaxed() {
            return currentTier >= getMaxTier();
        }
    }
    
    public static class ShardClickArea {
        public int x, y, width, height;
        public String bazaarId;
        public int quantity;
        
        public ShardClickArea(int x, int y, int width, int height, String bazaarId, int quantity) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.bazaarId = bazaarId;
            this.quantity = quantity;
        }
        
        public boolean isHovered(int mouseX, int mouseY) {
            return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
        }
    }
    
    public static List<Shard> createShardList() {
        List<Shard> shards = Collections.synchronizedList(new ArrayList<>());
        
        shards.add(new Shard("Flash (Light Elemental)", "SHARD_FLASH", 5.0, 400, "Common", "Flash"));
        shards.add(new Shard("Lapis Zombie", "SHARD_LAPIS_ZOMBIE", 8.0, 0, "Common", "Lapis Zombie"));
        shards.add(new Shard("Chill (Skeletal Ruler)", "SHARD_CHILL", 10.0, 100, "Common", "Chill"));
        shards.add(new Shard("Voracious Spider", "SHARD_VORACIOUS_SPIDER", 12.0, 100, "Common", "Voracious Spider"));
        shards.add(new Shard("Tank Zombie", "SHARD_TANK_ZOMBIE", 15.0, 100, "Common", "Tank Zombie"));
        shards.add(new Shard("Zealot (Ender Resistance)", "SHARD_ZEALOT", 18.0, 200, "Common", "Zealot"));
        shards.add(new Shard("Harpy", "SHARD_HARPY", 20.0, 100, "Common", "Harpy"));
        shards.add(new Shard("Golden Ghoul", "SHARD_GOLDEN_GHOUL", 25.0, 200, "Common", "Golden Ghoul"));
        shards.add(new Shard("Azure (Forest Strength)", "SHARD_AZURE", 22.0, 100, "Common", "Azure"));
        shards.add(new Shard("Bezal (Blazing Resistance)", "SHARD_BEZAL", 28.0, 200, "Common", "Bezal"));
        shards.add(new Shard("Yog", "SHARD_YOG", 30.0, 100, "Common", "Yog"));
        shards.add(new Shard("Miner Zombie", "SHARD_MINER_ZOMBIE", 12.0, 200, "Common", "Miner Zombie"));
        
        shards.add(new Shard("Quake (Stone Elemental)", "SHARD_QUAKE", 35.0, 400, "Uncommon", "Quake"));
        shards.add(new Shard("Troglobyte", "SHARD_TROGLOBYTE", 30.0, 200, "Uncommon", "Troglobyte"));
        shards.add(new Shard("Cuboa", "SHARD_CUBOA", 25.0, 300, "Uncommon", "Cuboa"));
        shards.add(new Shard("Rain Slime (Mana Steal)", "SHARD_RAIN_SLIME", 40.0, 400, "Uncommon", "Rain Slime"));
        shards.add(new Shard("Seer", "SHARD_SEER", 45.0, 0, "Uncommon", "Seer"));
        shards.add(new Shard("Obsidian Defender", "SHARD_OBSIDIAN_DEFENDER", 50.0, 400, "Uncommon", "Obsidian Defender"));
        shards.add(new Shard("Viper", "SHARD_VIPER", 35.0, 100, "Uncommon", "Viper"));
        shards.add(new Shard("Zombie Soldier", "SHARD_ZOMBIE_SOLDIER", 48.0, 300, "Uncommon", "Zombie Soldier"));
        shards.add(new Shard("Sycophant", "SHARD_SYCOPHANT", 55.0, 400, "Uncommon", "Sycophant"));
        shards.add(new Shard("Soul of the Alpha", "SHARD_SOUL_OF_THE_ALPHA", 65.0, 300, "Uncommon", "Soul of the Alpha"));
        shards.add(new Shard("Flaming Spider", "SHARD_FLAMING_SPIDER", 58.0, 300, "Uncommon", "Flaming Spider"));
        shards.add(new Shard("Bruiser (Ender Ruler)", "SHARD_BRUISER", 70.0, 400, "Uncommon", "Bruiser"));
        shards.add(new Shard("Rana", "SHARD_RANA", 45.0, 0, "Uncommon", "Rana"));
        
        shards.add(new Shard("Bolt (Lightning Elemental)", "SHARD_BOLT", 75.0, 400, "Rare", "Bolt"));
        shards.add(new Shard("Glacite Walker", "SHARD_GLACITE_WALKER", 80.0, 100, "Rare", "Glacite Walker"));
        shards.add(new Shard("Python", "SHARD_PYTHON", 65.0, 300, "Rare", "Python"));
        shards.add(new Shard("Lapis Skeleton", "SHARD_LAPIS_SKELETON", 55.0, 400, "Rare", "Lapis Skeleton"));
        shards.add(new Shard("Drowned (Humanoid Ruler)", "SHARD_DROWNED", 85.0, 300, "Rare", "Drowned"));
        shards.add(new Shard("Star Sentry", "SHARD_STAR_SENTRY", 90.0, 300, "Rare", "Star Sentry"));
        shards.add(new Shard("Arachne", "SHARD_ARACHNE", 100.0, 200, "Rare", "Arachne"));
        shards.add(new Shard("Revenant", "SHARD_REVENANT", 95.0, 300, "Rare", "Revenant"));
        shards.add(new Shard("Skeletor (Deadeye)", "SHARD_SKELETOR", 110.0, 500, "Rare", "Skeletor"));
        shards.add(new Shard("Thyst", "SHARD_THYST", 75.0, 300, "Rare", "Thyst"));
        shards.add(new Shard("Quartzfang", "SHARD_QUARTZFANG", 70.0, 300, "Rare", "Quartzfang"));
        shards.add(new Shard("Kada Knight (Lifeline)", "SHARD_KADA_KNIGHT", 120.0, 400, "Rare", "Kada Knight"));
        shards.add(new Shard("Wither Spectre (Breeze)", "SHARD_WITHER_SPECTRE", 130.0, 300, "Rare", "Wither Spectre"));
        shards.add(new Shard("Matcho (Ignition)", "SHARD_MATCHO", 115.0, 100, "Rare", "Matcho"));
        shards.add(new Shard("Crocodile", "SHARD_CROCODILE", 80.0, 500, "Rare", "Crocodile"));
        shards.add(new Shard("Stalagmight", "SHARD_STALAGMIGHT", 85.0, 300, "Rare", "Stalagmight"));
        shards.add(new Shard("King Cobra", "SHARD_KING_COBRA", 95.0, 400, "Rare", "King Cobra"));
        
        shards.add(new Shard("Draconic", "SHARD_DRACONIC", 150.0, 200, "Epic", "Draconic"));
        shards.add(new Shard("Wither", "SHARD_WITHER", 180.0, 300, "Epic", "Wither"));
        shards.add(new Shard("Aero (Wind Elemental)", "SHARD_AERO", 140.0, 400, "Epic", "Aero"));
        shards.add(new Shard("Alligator", "SHARD_ALLIGATOR", 125.0, 200, "Epic", "Alligator"));
        shards.add(new Shard("Basilisk", "SHARD_BASILISK", 135.0, 200, "Epic", "Basilisk"));
        shards.add(new Shard("Bal (Deep Technique)", "SHARD_BAL", 160.0, 200, "Epic", "Bal"));
        shards.add(new Shard("Flare (Blazing)", "SHARD_FLARE", 155.0, 400, "Epic", "Flare"));
        shards.add(new Shard("Prince (Reborn)", "SHARD_PRINCE", 145.0, 200, "Epic", "Prince"));
        shards.add(new Shard("Mimic (Faker)", "SHARD_MIMIC", 170.0, 300, "Epic", "Mimic"));
        shards.add(new Shard("Barbarian Duke X", "SHARD_BARBARIAN_DUKE_X", 185.0, 500, "Epic", "Barbarian Duke X"));
        shards.add(new Shard("Hellwisp", "SHARD_HELLWISP", 165.0, 200, "Epic", "Hellwisp"));
        shards.add(new Shard("Caiman", "SHARD_CAIMAN", 140.0, 300, "Epic", "Caiman"));
        shards.add(new Shard("Ghost (Veil)", "SHARD_GHOST", 175.0, 400, "Epic", "Ghost"));
        shards.add(new Shard("Cavernshade", "SHARD_CAVERNSHADE", 130.0, 200, "Epic", "Cavernshade"));
        
        shards.add(new Shard("Tempest (Storm Elemental)", "SHARD_TEMPEST", 220.0, 400, "Legendary", "Tempest"));
        shards.add(new Shard("Tiamat", "SHARD_TIAMAT", 250.0, 300, "Legendary", "Tiamat"));
        shards.add(new Shard("End Stone Protector", "SHARD_END_STONE_PROTECTOR", 200.0, 400, "Legendary", "End Stone Protector"));
        shards.add(new Shard("Lapis Creeper", "SHARD_LAPIS_CREEPER", 180.0, 200, "Legendary", "Lapis Creeper"));
        shards.add(new Shard("Kraken (Vitality)", "SHARD_KRAKEN", 240.0, 500, "Legendary", "Kraken"));
        shards.add(new Shard("Daemon (Pity)", "SHARD_DAEMON", 260.0, 500, "Legendary", "Daemon"));
        shards.add(new Shard("Ananke", "SHARD_ANANKE", 280.0, 400, "Legendary", "Ananke"));
        shards.add(new Shard("Burningsoul", "SHARD_BURNINGSOUL", 230.0, 400, "Legendary", "Burningsoul"));
        shards.add(new Shard("Power Dragon", "SHARD_POWER_DRAGON", 300.0, 500, "Legendary", "Power Dragon"));
        shards.add(new Shard("Apex Dragon", "SHARD_APEX_DRAGON", 320.0, 500, "Legendary", "Apex Dragon"));
        shards.add(new Shard("Jormung", "SHARD_JORMUNG", 290.0, 400, "Legendary", "Jormung"));
        shards.add(new Shard("Etherdrake", "SHARD_ETHERDRAKE", 310.0, 400, "Legendary", "Etherdrake"));
        shards.add(new Shard("Molthron", "SHARD_MOLTHRON", 270.0, 300, "Legendary", "Molthron"));
        shards.add(new Shard("Starborn", "SHARD_STARBORN", 285.0, 400, "Legendary", "Starborn"));
        
        return shards;
    }
}
